-- phpMyAdmin SQL Dump
-- version 2.6.4-pl1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generaci�n: 03-11-2005 a las 09:32:10
-- Versi�n del servidor: 3.23.58
-- Versi�n de PHP: 4.3.9
-- 
-- Base de datos: `grbuzon`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `FUNCIONARIO`
-- 

CREATE TABLE `FUNCIONARIO` (
  `COD_FUNCIONARIO` int(11) NOT NULL auto_increment,
  `NOMBRES` varchar(25) NOT NULL default '',
  `APPAT` varchar(15) NOT NULL default '',
  `APMAT` varchar(15) NOT NULL default '',
  `EMAIL` varchar(50) NOT NULL default '',
  `RUT` varchar(12) NOT NULL default '',
  `USER_FUNCIONARIO` varchar(25) NOT NULL default '',
  `PASS_FUNCIONARIO` varchar(25) NOT NULL default '',
  `TIPO_FUNCIONARIO` tinyint(4) NOT NULL default '0',
  `SESIONID` varchar(36) NOT NULL default '',
  PRIMARY KEY  (`COD_FUNCIONARIO`),
  KEY `USER_FN` (`USER_FUNCIONARIO`),
  KEY `RUT` (`RUT`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `FUNCIONARIO`
-- 

INSERT INTO `FUNCIONARIO` VALUES (1, 'Luis', 'Jimenez', 'Villalobos', 'luis.jimenez@sysco.cl', '11806842-4', 'ljimenez', 'ljyDWVXFD/u4E', 1, '78332e7d9dc24bc335f2ef6e6b24b21f');
INSERT INTO `FUNCIONARIO` VALUES (2, 'Usuario', 'Consulta', 'Correos', 'soporte@gorecoquimbo.cl', '111111111-1', 'buzon', 'buL67uXKN5ju.', 3, '20858e720f3e5d236ac0fd2f237d8497');
