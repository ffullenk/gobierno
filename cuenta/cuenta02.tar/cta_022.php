<?
include("utils.php");
cabeceraHTML();

echo <<< HTML
<table width="790" border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF" class="tablebody" style="border: 1px solid rgb(188,211,250);">
  <tr> 
    <td width="170" valign="top" rowspan="5" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td width="150" height="278" valign="top" bgcolor="#FFFFFF">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
	      <tr><td></td></tr>
	      <tr>
		<td class="leftmenu" height="25">
			<a href="index.php">Introducci&oacute;n</a>
		</td>
	      </tr>
	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_02.php">Cuenta Gesti&oacute;n 2002</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_021.php">M&aacute;s Equidad</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_022.php">M&aacute;s Integraci&oacute;n</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_023.php">M&aacute;s Progreso</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_024.php">M&aacute;s Eficiencia</a>
                </td>
              </tr>
<tr>
                <td class="leftmenu" height="25">
                        <a href="cta_04.php">Tareas Pendientes</a>
                </td>
              </tr>

	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_03.php">Cierre</a>
                </td>
              </tr>

	    </table>
	  </td>
        </tr>
      </table>
    </td>
    <td width="16" height="25"></td>
    <td width="120"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="6"></td>
    <td width="107"></td>
    <td width="13"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="4"></td>
    <td width="120" valign="top" rowspan="5" > 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="18" height="42"></td>
          <td width="78"></td>
          <td width="18"></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/gore.gif" border="0" width="80" height="80"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="2"></td>
          <td></td>
          <td></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/chile.gif" border="0" width="80" height="67"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="56"></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="126"></td>
    <td colspan="5" valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="360" height="126">
              <DIV align="left" style="padding-left : 5px;    border: 1px solid #DDE5F2; HEIGHT: 126px; OVERFLOW: auto; WIDTH: 100%">
	<font class="tablebodytext">
<p>
M�S INTEGRACI�N<BR><BR>
Todas estas acciones, est�n acompa�adas de un plan de infraestructura que ayuda a su realizaci�n.  La existencia de un soporte que posibilite el adecuado desarrollo de los habitantes de esta zona del pa�s, es el sustento cuando hablamos de generar M�s Integraci�n.<BR><BR>
En estos trece a�os de gobierno de Concertaci�n hemos avanzado sustancialmente en materia de infraestructura. Se ha consolidado una red vial a lo largo de nuestra regi�n; se han construido embalses que han cambiado la vocaci�n productiva de nuestro territorio. Con gran orgullo asistimos en el 2002 al primer vertimiento del embalse Puclaro, que asegura el riego del valle de Elqui por un horizonte de tres a�os.<BR><BR>
Toda esta gran inversi�n en infraestructura es la que nos permite hoy enfrentar el desarrollo integral de nuestra regi�n.<BR><BR>
</p>

<p>
<B>SOLUCIONES HABITACIONALES</B><BR><BR>
Hoy, seis de cada diez pesos que se invierten en vivienda van al 30 por ciento m�s pobre de los chilenos.  Pero esos seis pesos, encuentran una excelente contraparte en el esfuerzo realizado por cada una de las familias que los reciben, quienes con sacrificio se convierten en art�fices de su propio desarrollo.<BR><BR>
Es gracias a ese esfuerzo que podemos mostrar un significativo avance en el sector habitacional.<BR><BR>
Hab�amos prometido que para el a�o 2002, el Gobierno entregar�a 4 mil 820 soluciones habitacionales, a trav�s de subsidios para las familias que requieren de la ayuda del Estado para obtener su casa propia, y aquellas viviendas que construye y entrega directamente el Serviu Regional.<BR><BR>
Es un orgullo el poder decir que, gracias a una gesti�n eficiente y coordinada, hemos superado largamente esa proyecci�n, ya que el a�o pasado se entregaron 5 mil 955 soluciones habitacionales, lo que claramente mejor� la calidad de vida de las familias y gener� gran cantidad de mano de obra en la construcci�n.  <BR><BR>
Claramente, aqu� vemos que se ha duplicado el n�mero de viviendas construidas, con lo que estamos reduciendo considerablemente el d�ficit habitacional de la Regi�n.<BR><BR>
Avanzamos en el mejoramiento de las condiciones de vida de distintas zonas de la Regi�n, lo que es reflejo, una vez m�s, de un trabajo transversal.<BR><BR>
A trav�s del programa Chile Barrio, y con la participaci�n del Serviu, Prodemu, Sence, la Direcci�n de Obras Hidr�ulicas, el Ministerio de Educaci�n y, por supuesto, el Gobierno Regional, se dio soluci�n a 12 asentamientos, favoreciendo a 1.241 familias.<BR><BR>
Para este a�o, queremos que otras 1.300 familias obtengan una vivienda digna, a trav�s de la erradicaci�n de 11 asentamientos.<BR><BR>
</p>

<p>
<B>ORDENAMIENTO TERRITORIAL</B><BR><BR>
Adem�s, se ha iniciado la formulaci�n del plano regulador de la comuna de La Higuera, al mismo tiempo que se est�n actualizando los planes reguladores de las comunas de Monte Patria y Salamanca.  Tambi�n est� en ejecuci�n el plan de recuperaci�n de la ribera urbana del r�o Elqui.  <BR><BR>
Esto ha tenido un valor total de 220 millones de pesos y constituye un paso fundamental para un progreso ordenado de estos territorios, lo que entrega pautas claras para la atracci�n de nuevas inversiones.<BR><BR>
Tambi�n se contrat� el estudio para el plan regional de desarrollo urbano de la Regi�n de Coquimbo, por un monto de 75 millones de pesos.  Esto significa tener, por primera vez, un plan regulador regional.<BR><BR>
El esp�ritu que mueve al Consejo Regional, es el de entregar posibilidades a la poblaci�n.  Por eso, se financi� la regularizaci�n de  700 t�tulos de dominio para sectores urbanos y rurales.  Los 47 millones de pesos designados para esta materia, permiten que esos casos ahora puedan postular a otras v�as de financiamiento para la obtenci�n de sus viviendas o el mejoramiento de su entorno habitacional.<BR><BR>
Tenemos la mirada puesta en el desarrollo futuro, las posibilidades de crecimiento del territorio costero, se ven aumentadas por el Programa de Fortalecimiento de la Comisi�n de Uso del Borde Costero.<BR><BR>
Mediante este instrumento cofinanciado por el Gobierno Regional y el Programa M�s Regi�n, se pretende entregar una base conceptual com�n para el manejo integrado de zonas costeras, tanto por agentes estatales como del mundo privado.<BR><BR>
</p>

<p>
<B>INFRAESTRUCTURA VIAL</B><BR><BR>
Para asegurar el desarrollo de los 40.580 kil�metros cuadrados de superficie de nuestra Regi�n, con fondos regionales y sectoriales, se ha mejorado la interconectividad tanto al interior de cada ciudad y poblado, como su comunicaci�n con el resto del Pa�s.<BR><BR>
Terminamos la construcci�n del eje Bellavista, en Ovalle, inversi�n de mil 364 millones de pesos que conect� a un importante sector poblacional de la capital del Limar� con el centro de la ciudad.<BR><BR>
A esto sumamos, la entrega del eje Amun�tegui, obra que tuvo un valor de 5.100 millones en sus tres etapas.<BR><BR>
Adem�s, alrededor de 20 mil metros lineales fueron pavimentados al interior de los barrios, gracias al programa Pavimentaci�n Participativa, que financi� 83 proyectos.  Aqu� el trabajo de la comunidad organizada coordinado con los municipios y el Gobierno, ha significado una mejora considerable en la calidad de vida de dos mil 336 familias <BR><BR>
En el �mbito de infraestructura vial, este a�o esperamos avanzar en la realizaci�n de los cruces de la ruta 5 con Cuatro Esquinas y la Avenida Pe�uelas, en la conurbaci�n La Serena-Coquimbo.  Para estas obras, ya se adjudic� el estudio de ingenier�a.<BR><BR>
Pero como no s�lo queremos que en torno a la Ruta 5 se genere el progreso de los territorios, hemos querido diversificar hacia los valles, mediante la instalaci�n de un camino longitudinal interior.  El 70 por ciento de avance del camino Auc�-Los Pozos, en la provincia del Choapa, as� lo comprueba.<BR><BR>
Para este a�o, esperamos terminar con esta obra y poner en operaci�n la ruta en los tramos Los Pozos-Combarbal�, Angostura de G�lvez-Combarbal� y Canela Alta-Los Pozos durante el primer semestre.<BR><BR>
As�, este a�o estar� completamente pavimentado el tramo La Serena-Illapel, y estaremos sentando las bases de la apertura del interior de los valles hacia el sur del pa�s.  <BR><BR>
</p>

<p>
<B>OBRAS EMBLEM�TICAS</B><BR><BR>
El Plan Bicentenario anunciado por el Presidente Lagos, contempla dotar de infraestructura al pa�s para entrar de lleno a los mercados internacionales.  <BR><BR>
La reciente firma del acuerdo para el financiamiento conjunto entre el Gobierno Regional y el Gobierno de la Rep�blica Argentina del estudio de prefactibilidad del t�nel paso Agua Negra, muestra una clara disposici�n pol�tica y econ�mica para la apertura definitiva de este corredor bioce�nico.<BR><BR>
El car�cter prioritario de esta inversi�n para ambos Gobiernos, fue reafirmada por la reciente visita del Vicepresidente argentino a La Serena y Coquimbo, y la posterior recepci�n en la Casa Rosada, de la delegaci�n regional encabezada por este Intendente.<BR><BR>
Al mismo tiempo, estamos trabajando en el mejoramiento de la ruta D 41 en el tramo Huanta-Juntas, que con una inversi�n de dos mil millones de pesos, nos prepara para el momento en que el tr�nsito de mercanc�as y turistas sea continuo.<BR><BR>
Otra obra contemplada en el Plan Bicentenario, es la construcci�n del Puerto Pesquero Artesanal de Coquimbo.  Los trabajos, para los que se han destinado 3.900 millones de pesos, ya se encuentran en ejecuci�n, y tienen fecha de t�rmino estimada para noviembre de 2004.<BR><BR>
Esta nueva infraestructura que beneficiar� a 900 pescadores y sus familias, va acompa�ada de la extensi�n de la Costanera de Coquimbo hasta su uni�n con la Av. del Mar, en La Serena.  As�, potenciamos un sector caracter�stico, y posibilitamos su desarrollo inmobiliario futuro.  <BR><BR>
En diciembre del a�o pasado, asistimos a la inauguraci�n del Instituto Telet�n de Coquimbo, que permite la atenci�n a los ni�os minusv�lidos de toda la Regi�n que hasta ahora deb�an trasladarse hasta Santiago, Valpara�so o Antofagasta.  El centro, que comenz� a operar la semana pasada, demand� una inversi�n proveniente del FNDR, por un valor de 745 millones de pesos, incluido su equipamiento.  Esto fue complementado por la donaci�n de la junta de vecinos del sector Baquedano de Coquimbo, que entreg� el terreno en que se emplaza la construcci�n.<BR><BR>

	</font>
	      </DIV>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr> 
          <td width="120" height="126" align="center"><img src="imagenes/boss.jpg" border="0" height="126"></td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="95"></td>
    <td valign="top"  class="tableborder"> 
<table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas01.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas011.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas02.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas021.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td colspan="2" valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="1220" height="25" valign="top"><img src="imagenes/mas03.gif" width="122" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas031.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas04.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas041.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>

    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
HTML;
?>
