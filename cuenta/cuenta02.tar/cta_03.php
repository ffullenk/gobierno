<?
include("utils.php");
cabeceraHTML();

echo <<< HTML
<table width="790" border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF" class="tablebody" style="border: 1px solid rgb(188,211,250);">
  <tr> 
    <td width="170" valign="top" rowspan="5" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td width="150" height="278" valign="top" bgcolor="#FFFFFF">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
	      <tr><td></td></tr>
	      <tr>
		<td class="leftmenu" height="25">
			<a href="index.php">Introducci&oacute;n</a>
		</td>
	      </tr>
	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_02.php">Cuenta Gesti&oacute;n 2002</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_021.php">M&aacute;s Equidad</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_022.php">M&aacute;s Integraci&oacute;n</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_023.php">M&aacute;s Progreso</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_024.php">M&aacute;s Eficiencia</a>
                </td>
              </tr>
<tr>
                <td class="leftmenu" height="25">
                        <a href="cta_04.php">Tareas Pendientes</a>
                </td>
              </tr>

	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_03.php">Cierre</a>
                </td>
              </tr>

	    </table>
	  </td>
        </tr>
      </table>
    </td>
    <td width="16" height="25"></td>
    <td width="120"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="6"></td>
    <td width="107"></td>
    <td width="13"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="4"></td>
    <td width="120" valign="top" rowspan="5" > 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="18" height="42"></td>
          <td width="78"></td>
          <td width="18"></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/gore.gif" border="0" width="80" height="80"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="2"></td>
          <td></td>
          <td></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/chile.gif" border="0" width="80" height="67"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="56"></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="126"></td>
    <td colspan="5" valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="360" height="126">
              <DIV align="left" style="padding-left : 5px;    border: 1px solid #DDE5F2; HEIGHT: 126px; OVERFLOW: auto; WIDTH: 100%">
	<font class="tablebodytext">
CIERRE<BR><BR>
Autoridades y amigos presentes, lo realizado demuestra que cuando nos entendemos en las materias donde se juega el bien com�n, podemos avanzar a pasos agigantados.<BR><BR>
El desarrollo equitativo de nuestra Regi�n, es tarea de todos.  Los invito a participar de este desaf�o de llegar al Bicentenario con un pa�s desarrollado, que extiende su �xito a todos sus hijos.<BR><BR>
���Trabajemos juntos por la Regi�n!!!<BR><BR>
Muchas gracias.

	</font>
	      </DIV>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr> 
          <td width="120" height="126" align="center"><img src="imagenes/boss.jpg" border="0" height="126"></td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="95"></td>
    <td valign="top"  class="tableborder"> 
<table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas01.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas011.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas02.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas021.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td colspan="2" valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="1220" height="25" valign="top"><img src="imagenes/mas03.gif" width="122" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas031.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas04.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas041.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>

    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
HTML;
?>
