<?
include("utils.php");
cabeceraHTML();

echo <<< HTML
<table width="790" border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF" class="tablebody" style="border: 1px solid rgb(188,211,250);">
  <tr> 
    <td width="170" valign="top" rowspan="5" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td width="150" height="278" valign="top" bgcolor="#FFFFFF">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
	      <tr><td></td></tr>
	      <tr>
		<td class="leftmenu" height="25">
			<a href="index.php">Introducci&oacute;n</a>
		</td>
	      </tr>
	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_02.php">Cuenta Gesti&oacute;n 2002</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_021.php">M&aacute;s Equidad</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_022.php">M&aacute;s Integraci&oacute;n</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_023.php">M&aacute;s Progreso</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_024.php">M&aacute;s Eficiencia</a>
                </td>
              </tr>
<tr>
                <td class="leftmenu" height="25">
                        <a href="cta_04.php">Tareas Pendientes</a>
                </td>
              </tr>

	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_03.php">Cierre</a>
                </td>
              </tr>

	    </table>
	  </td>
        </tr>
      </table>
    </td>
    <td width="16" height="25"></td>
    <td width="120"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="6"></td>
    <td width="107"></td>
    <td width="13"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="4"></td>
    <td width="120" valign="top" rowspan="5" > 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="18" height="42"></td>
          <td width="78"></td>
          <td width="18"></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/gore.gif" border="0" width="80" height="80"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="2"></td>
          <td></td>
          <td></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/chile.gif" border="0" width="80" height="67"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="56"></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="126"></td>
    <td colspan="5" valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="360" height="126">
              <DIV align="left" style="padding-left : 5px;    border: 1px solid #DDE5F2; HEIGHT: 126px; OVERFLOW: auto; WIDTH: 100%">
	<font class="tablebodytext">
<p>
<B>M�S EFICIENCIA</B><BR><BR>
El �ltimo soporte de la Estrategia de Desarrollo, el que est� en la base de todo, es la eficiencia.<BR><BR>
Si bien todo lo enunciado con anterioridad lleva el concepto de eficiencia en su concepci�n y desarrollo, modernizar la gesti�n p�blica es un imperativo que nos hemos fijado como administraci�n regional.<BR><BR>
Por eso, el sello de esta gesti�n se ha radicado en la constituci�n de equipos de trabajo al interior del Gabinete Regional.<BR><BR>
Estos equipos, que se organizan de acuerdo a los ejes de nuestra Estrategia Regional de Desarrollo, son:<BR><BR>
-	el comit� de fomento productivo, <BR><BR>
-	el comit� social, <BR><BR>
-	el comit� de ordenamiento territorial e infraestructura<BR><BR>
-	 y el comit� de modernizaci�n, <BR><BR>
-	los cuales se articulan con la Unidad de Gesti�n Estrat�gica.<BR><BR>
La transversalidad desarrollada al interior de estos equipos, ha generado la integraci�n del trabajo de los distintos sectores, que ha hecho posible gran parte de los logros destacados en esta cuenta.<BR><BR>
Otra caracter�stica modernizadora de nuestro Gobierno, ha sido la selecci�n de los secretarios ministeriales y directores de servicio a trav�s de invitaciones p�blicas.  Esta pr�ctica, junto con aportar a la transparencia de la gesti�n, nos ha permitido contar con profesionales altamente calificados y con vocaci�n de servicio.<BR><BR>
Hemos sido pioneros en el pa�s en aplicar este modelo, validado por el Presidente Lagos al anunciar que un n�mero importante de cargos de confianza del Gobierno, ser�n ejercidos por personas que hayan pasado por un proceso de selecci�n p�blica.<BR><BR>
</p>

<p>
<B>CALIDAD DE SERVICIO</B><BR><BR>
El mejoramiento de la gesti�n debe ser algo que perciban efectivamente los ciudadanos, mediante un trato amable, con respuestas r�pidas y de calidad. <BR><BR>
En funci�n de esto, se gener� un instrumento de apoyo a la calidad de servicio en las organizaciones p�blicas, que puso el acento en la relaci�n con los usuarios.  <BR><BR>
Durante el a�o pasado, se realiz� una medici�n de la calidad de servicio entregado por ocho instituciones p�blicas.  Este estudio realizado por la Universidad del Mar, arroj� las directrices sobre qu� mejorar en la atenci�n a los usuarios de los servicios, lo que ya est� en aplicaci�n.<BR><BR>
</p>

<p>
<B>GOBIERNO ELECTR�NICO</B><BR><BR>
El uso de las nuevas tecnolog�as de la informaci�n y comunicaci�n, es un medio eficaz para mejorar la gesti�n y la relaci�n en tiempo real con los ciudadanos y las empresas.<BR><BR>
En octubre del a�o reci�n pasado, se lanz� oficialmente el portal web del Gobierno Regional, espacio de vinculo virtual con el mundo.  <BR><BR>
Tambi�n, el Consejo Regional aprob� el Proyecto Gobierno Electr�nico que busca promover el uso de las nuevas tecnolog�as por parte de la ciudadan�a.<BR><BR>
La marcha blanca del Sistema Electr�nico de Evaluaci�n de Impacto Ambiental, la existencia de formularios como los representados por el bono electr�nico de FONASA o la declaraci�n de impuestos v�a internet, son un ejemplo de los 110 servicios virtuales que el Gobierno tiene hoy disponibles en internet<BR><BR>
</p>

<p>
<B>PARTICIPACI�N CIUDADANA</B><BR><BR>
Sin embargo, el esfuerzo modernizador de la gesti�n es en vano si no se sustenta en una fuerte participaci�n ciudadana.  Estamos convencidos que la igualdad de oportunidades no pasa s�lo por la entrega de recursos, sino tambi�n por escuchar lo que la ciudadan�a tiene que decir.<BR><BR>
Por eso es que una vez al mes, el Gabinete Regional en pleno se traslad� a diferentes comunas y localidades para escuchar de primera fuente las necesidades de la poblaci�n.  En cada una de estas ocasiones, la comunidad pudo participar de plazas ciudadanas, que le permitieron conocer directamente el accionar de Gobierno.<BR><BR>
A esto, sumamos la realizaci�n del programa radial Gobierno en L�nea, contacto quincenal en que el Gobierno en la Regi�n, personificado en la persona del Intendente acompa�ado por distintos secretarios regionales y directores de servicios, dio respuesta a las consultas de la poblaci�n.<BR><BR>
Durante este a�o, seguiremos con el trabajo en terreno, privilegiando la relaci�n directa con las personas.<BR><BR>
</P>

	</font>
	      </DIV>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr> 
          <td width="120" height="126" align="center"><img src="imagenes/boss.jpg" border="0" height="126"></td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="95"></td>
    <td valign="top"  class="tableborder"> 
<table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas01.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas011.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas02.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas021.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td colspan="2" valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="1220" height="25" valign="top"><img src="imagenes/mas03.gif" width="122" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas031.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas04.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas041.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>

    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
HTML;
?>
