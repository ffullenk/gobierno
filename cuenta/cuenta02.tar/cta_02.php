<?
include("utils.php");
cabeceraHTML();

echo <<< HTML
<table width="790" border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF" class="tablebody" style="border: 1px solid rgb(188,211,250);">
  <tr> 
    <td width="170" valign="top" rowspan="5" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td width="150" height="278" valign="top" bgcolor="#FFFFFF">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
	      <tr><td></td></tr>
	      <tr>
		<td class="leftmenu" height="25">
			<a href="index.php">Introducci&oacute;n</a>
		</td>
	      </tr>
	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_02.php">Cuenta Gesti&oacute;n 2002</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_021.php">M&aacute;s Equidad</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_022.php">M&aacute;s Integraci&oacute;n</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_023.php">M&aacute;s Progreso</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_024.php">M&aacute;s Eficiencia</a>
                </td>
              </tr>
<tr>
                <td class="leftmenu" height="25">
                        <a href="cta_04.php">Tareas Pendientes</a>
                </td>
              </tr>

	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_03.php">Cierre</a>
                </td>
              </tr>

	    </table>
	  </td>
        </tr>
      </table>
    </td>
    <td width="16" height="25"></td>
    <td width="120"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="6"></td>
    <td width="107"></td>
    <td width="13"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="4"></td>
    <td width="120" valign="top" rowspan="5" > 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="18" height="42"></td>
          <td width="78"></td>
          <td width="18"></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/gore.gif" border="0" width="80" height="80"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="2"></td>
          <td></td>
          <td></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/chile.gif" border="0" width="80" height="67"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="56"></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="126"></td>
    <td colspan="5" valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="360" height="126">
              <DIV align="left" style="padding-left : 5px;    border: 1px solid #DDE5F2; HEIGHT: 126px; OVERFLOW: auto; WIDTH: 100%">
	<font class="tablebodytext">
II. Cuenta Gesti�n 2002<BR><BR>
El a�o pasado, cerraba la entrega de la cuenta del a�o 2001 diciendo que este era un gobierno que trabaja para y con las personas.<BR><BR>
Por eso es que durante el a�o anterior, la gesti�n tuvo un sello transversal, donde cada uno de los sectores debi� articular sus acciones no s�lo con otros entes del aparato gubernamental, sino tambi�n con el sector privado y estatal.<BR><BR>
Los requerimientos de la ciudadan�a de las comunas de Los Vilos, Salamanca, Canela, e Illapel; de Combarbal�, Punitaqui, Monte Patria, R�o Hurtado y Ovalle; de Paihuano, Andacollo, Vicu�a, La Higuera, La Serena y Coquimbo, merecen una respuesta integral que no se agote en acciones aisladas.<BR><BR>
El detalle de las inversiones realizadas a trav�s del Fondo Nacional de Desarrollo Regional, y por cada uno de los servicios durante el a�o 2002, ser� entregado al Consejo Regional al t�rmino de esta sesi�n, y quedar� a disposici�n de la comunidad a trav�s de la p�gina web del Gobierno Regional y de las oficinas de informaci�n de las gobernaciones provinciales.<BR><BR>
El a�o pasado, conseguimos grandes logros. Pudimos ver avances en todas las �reas, con la generaci�n de los espacios de di�logo necesarios, y el acuerdo de todos los actores, de todos aquellos que entienden que el bienestar de la Regi�n, que el futuro de Chile est� primero.<BR><BR>
Y el mejor ejemplo de esta voluntad, lo simboliza el Consejo Regional de Coquimbo.  En este �rgano colegiado, que responde a la diversidad pol�tica y territorial de esta Regi�n, durante el a�o anterior conseguimos la unanimidad de criterios para priorizar la inversi�n regional 2003.  Esto, nos entrega una excelente base sobre la cual cimentar el desarrollo futuro de la Regi�n.<BR><BR>
Y por eso, me enorgullece se�alar que la visi�n estrat�gica de la Regi�n que queremos, no se agota en la b�squeda de popularidad o de reconocimiento inmediato a nuestra labor como Gobierno, sino que pone el acento en el desarrollo duradero de nuestro territorio.<BR><BR>
Queremos construir oportunidades de futuro.  Gran parte de las obras generadas y ejecutadas durante este bienio 2002-2003, apuntan a ser ese trampol�n, que permita la proyecci�n, el desarrollo de todo el potencial de los habitantes de la Regi�n de Coquimbo.<BR><BR>
El Presidente Ricardo Lagos nos ha encomendado una tarea que compromete a todos los sectores de la naci�n: llegar al bicentenario de Chile como un pa�s desarrollado.<BR><BR>
Lo hacemos considerando cuatro ejes fundamentales, cuatro deas fuerza contenidas en nuestra Estrategia Regional de Desarrollo:<BR><BR>
-	M�s equidad<BR><BR>
-	M�s integraci�n<BR><BR>
-	M�s progreso<BR><BR>
-	M�s eficiencia<BR><BR>

	</font>
	      </DIV>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr> 
          <td width="120" height="126" align="center"><img src="imagenes/boss.jpg" border="0" height="126"></td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="95"></td>
    <td valign="top"  class="tableborder"> 
<table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas01.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas011.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas02.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas021.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td colspan="2" valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="1220" height="25" valign="top"><img src="imagenes/mas03.gif" width="122" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas031.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas04.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas041.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>

    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
HTML;
?>
