<?
include("utils.php");
cabeceraHTML();

echo <<< HTML
<table width="790" border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF" class="tablebody" style="border: 1px solid rgb(188,211,250);">
  <tr> 
    <td width="170" valign="top" rowspan="5" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td width="150" height="278" valign="top" bgcolor="#FFFFFF">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
	      <tr><td></td></tr>
	      <tr>
		<td class="leftmenu" height="25">
			<a href="index.php">Introducci&oacute;n</a>
		</td>
	      </tr>
	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_02.php">Cuenta Gesti&oacute;n 2002</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_021.php">M&aacute;s Equidad</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_022.php">M&aacute;s Integraci&oacute;n</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_023.php">M&aacute;s Progreso</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_024.php">M&aacute;s Eficiencia</a>
                </td>
              </tr>
<tr>
                <td class="leftmenu" height="25">
                        <a href="cta_04.php">Tareas Pendientes</a>
                </td>
              </tr>

	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_03.php">Cierre</a>
                </td>
              </tr>

	    </table>
	  </td>
        </tr>
      </table>
    </td>
    <td width="16" height="25"></td>
    <td width="120"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="6"></td>
    <td width="107"></td>
    <td width="13"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="4"></td>
    <td width="120" valign="top" rowspan="5" > 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="18" height="42"></td>
          <td width="78"></td>
          <td width="18"></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/gore.gif" border="0" width="80" height="80"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="2"></td>
          <td></td>
          <td></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/chile.gif" border="0" width="80" height="67"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="56"></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="126"></td>
    <td colspan="5" valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="360" height="126">
              <DIV align="left" style="padding-left : 5px;    border: 1px solid #DDE5F2; HEIGHT: 126px; OVERFLOW: auto; WIDTH: 100%">
	<font class="tablebodytext">
M�S EQUIDAD<BR><BR>
Queremos igualar las oportunidades para los ciudadanos.  Queremos nivelar a nuestra poblaci�n, pero queremos hacerlo .hacia arriba., llevando las posibilidades hacia aquellos que las necesitan pero que muchas veces no saben c�mo acceder a ellas.  Eso es la equidad.<BR><BR>

<p>
<b>EDUCACI�N</b><BR><BR>
Tenemos plena claridad que necesitamos generar habilidades y capacidades en las personas, con el objeto de asegurarles una vida digna y un desarrollo integral.<BR><BR>
Por eso, en la base de todo est� la educaci�n.<BR><BR>
Estamos poniendo nuevas metas, nuevos desaf�os, que requieren, necesariamente, de la preparaci�n de todos y todas.<BR><BR>
El principal de estos desaf�os, es que no queden ni�os y j�venes sin acceso a una educaci�n completa.  Por eso es que el presidente Lagos propici� los doce a�os de escolaridad obligatoria, porque este pa�s que sale al mundo, necesita de ciudadanos m�s y mejor preparados.<BR><BR>
Durante el 2002, se integraron a la Jornada Escolar Completa, 27 establecimientos educacionales en nuestra Regi�n, lo que signific� una inversi�n de m�s de 3 mil 600 millones de pesos provenientes de Fondos Regionales y Ministeriales<BR><BR>
En esta materia, hay una apuesta clara que se demuestra en el �ltimo acuerdo del Consejo Regional, que incorpora a 30 nuevos establecimientos a esta modalidad en un horizonte de tres a�os.  La inversi�n conjunta supera los 20 mil millones de pesos, lo que equivale, aproximadamente, a dos a�os de presupuesto regional.<BR><BR>
Con esto, cubriremos, aproximadamente,  un 70 por ciento del total de las escuelas que deben incorporarse a la Jornada Escolar Completa en nuestra Regi�n, lo que significa que 26 mil 171 ni�os ver�n mejorados sus est�ndares educacionales.<BR><BR>
Vivimos en la era de la globalizaci�n, donde tenemos que estar preparados para aprovechar al m�ximo las oportunidades que se nos ofrecen.  Esta es una necesidad ineludible.<BR><BR>
Por eso es que el acceso a las nuevas tecnolog�as, debe ser igualitario.  <BR><BR>
La red Enlaces, incorpor� durante el 2002 a 28 establecimientos rurales y a 11 urbanos a las tecnolog�as de la informaci�n.  En esa misma senda, para este a�o queremos que 72 nuevos establecimientos, 55 rurales y 17 urbanos de ense�anza b�sica y media, ingresen a este sistema que incorpora la inform�tica como un medio para mejorar los aprendizajes y la gesti�n educativa.<BR><BR>
La importancia del proyecto, nos llev� a implementar lo que llamamos .Red Enlaces abierta a la comunidad., en que los padres y la poblaci�n vecina a trece colegios y liceos, accede desde el a�o pasado a internet, al t�rmino de la jornada de clases.<BR><BR>
En el mismo sentido, se ejecut� la primera etapa del proyecto .Biblioredes abre tu mundo., que incorpor� a las bibliotecas p�blicas de la regi�n al uso de internet.  La segunda etapa de esta iniciativa, que combina los esfuerzos del gobierno y el aporte de la fundaci�n Bill y Melinda Gates, se aplicar� durante este a�o, y tiene que ver con la capacitaci�n en el uso de estas tecnolog�as.<BR><BR>
Hablamos de mejorar la educaci�n, y este es un deber que tomamos no como una mera declaraci�n de principios e intenciones, sino como un paso a la acci�n.  <BR><BR>
Lo primero, es capacitar a los principales agentes de este cambio: a los profesores.  La reforma educacional se hace con ellos, mejorando su calificaci�n profesional, posibilitando su perfeccionamiento y entreg�ndoles m�s herramientas.  As� lo entiende el Consejo Regional, y por eso es que destin� los recursos para acrecentar el capital pedag�gico de los docentes de nuestra regi�n.<BR><BR>
Esto va de la mano con el Plan de Evaluaci�n y Certificaci�n de Profesores desarrollado durante el 2002, que benefici� a 15 docentes que se calificaron e innovaron concretamente en el aula, lo que signific� mejorar sus ingresos.  Por eso, quiero invitarlos a postular al llamado de este a�o.<BR><BR>
En el segundo semestre de este a�o, iniciaremos la habilitaci�n del Centro de Innovaci�n Pedag�gica y Desarrollo Cultural en la Secretar�a Ministerial de Educaci�n, proyecto aprobado y financiado por el Fondo Nacional de Desarrollo Regional, cuya modelaci�n apreciamos en este momento. <BR><BR>
Esta es una apuesta �nica en el pa�s: un espacio abierto a la comunidad, donde esperamos potenciar y fortalecer los aprendizajes, para que los estudiantes desarrollen sus potencialidades. Adem�s, apoyar� y generar� condiciones para que los profesores de las quince comunas mejoren la calidad de la ense�anza que imparten en sus liceos.<BR><BR>
Este punto de encuentro, es una apuesta y un compromiso para democratizar y diversificar la cultura, mediante la instalaci�n de un nuevo espacio para el arte y la puesta en marcha de un infocentro que se suma a los trece ya existentes en la Regi�n.<BR><BR>
La meta de doce a�os de escolaridad, nos compromete a evitar la deserci�n y generar las posibilidades para que ning�n ni�o abandone la educaci�n.  <BR><BR>
En ese entendido, y con una inversi�n regional de 248 millones de pesos, conseguimos asegurar que siete localidades rurales de las comunas de Ovalle, Monte Patria y Combarbal�, cuenten con buses para el traslado de los ni�os a sus escuelas.  Estos 200 ni�os beneficiados, ya no tienen motivo para desertar de sus estudios.<BR><BR>
Pese a las dificultades econ�micas, m�s del 60 por ciento de la inversi�n que el Gobierno realiza en la Regi�n, se destina a educaci�n.  <BR><BR>
���Aqu�, ciudadanos y amigos, estamos construyendo futuro!!!<BR><BR>
Estas son obras que no s�lo tienen un impacto claro e innegable hoy: son una apuesta a la generaci�n del bicentenario, a los que vivir�n y construir�n el futuro de nuestra Regi�n.<BR><BR>
</p>

<p>
<b>REFORMA SALUD</b><BR><BR>
Queremos evitar las desigualdades en todos los aspectos.  Por eso, dar una mejor atenci�n de salud a todos los ciudadanos, es nuestro norte.<BR><BR>
Durante el a�o pasado, 238 millones de pesos de fondos regionales, se destinaron al equipamiento y reposici�n de equipos en los hospitales de Ovalle, Los Vilos, La Serena, Coquimbo y Combarbal�.<BR><BR>
Esto va acompa�ado de una mejora en la gesti�n de los centros cl�nicos, mediante un uso racional de los recursos y el cobro oportuno de seguros escolares y de accidentes de tr�nsito, adem�s de las prestaciones entregadas a los afiliados al sistema privado de salud.<BR><BR>
Todo esto debe ir acompa�ado de mejores est�ndares en la atenci�n a los pacientes. <BR><BR>
Hace unos momentos, ve�amos la historia de Cristal, una ni�a de dos a�os que debi� enfrentar una complicada patolog�a cardiaca, a lo que se sumaban dificultades econ�micas para enfrentar la enfermedad.<BR><BR>
Personalmente fui testigo, con cierta impotencia, de la desesperaci�n vivida por la familia.  <BR><BR>
Afortunadamente, la Reforma del Sistema de Salud, con el desarrollo del Plan AUGE, fue la respuesta para ellos.<BR><BR>
Esta reforma, que busca terminar con esas preocupaciones y mejorar la calidad de la atenci�n entregada a los usuarios del sistema p�blico de salud, permiti� que durante la aplicaci�n de la primera etapa del plan AUGE piloto en la Regi�n, se atendieran 21 casos de cardiopat�as cong�nitas, c�ncer infantil e insuficiencia renal.  Cristal es uno de estos 21 casos, pero queremos entregar soluci�n no s�lo a ella, sino a todas las personas que se encuentren en una situaci�n similar.<BR><BR>
���La regi�n quiere y necesita una reforma como la propuesta!!!. <BR><BR>
</p>

<p>
<b>SEGURIDAD CIUDADANA</b><BR><BR>
Si bien tanto la reforma educacional como la reforma de la salud implican una mirada hacia el futuro, consideramos que no es posible la construcci�n de un mejor porvenir sin una comunidad organizada que contribuya a la paz social.<BR><BR>
El vicepresidente argentino, durante su visita a la Regi�n hace un par de semanas, expresaba su admiraci�n por el ambiente de tranquilidad y orden reinante en las ciudades de La Serena y Coquimbo.  Este es un activo que debemos conservar y profundizar.<BR><BR>
Por eso es que durante el a�o pasado, se integr� a la comuna de Coquimbo, la m�s poblada de la Regi�n, al plan Comuna Segura del Ministerio del Interior, que interviene directamente en los barrios.  Esto significa que en el 2003 contaremos con m�s de 60 millones de pesos para iniciativas de seguridad presentadas por la comunidad organizada de acuerdo a sus necesidades espec�ficas. Coquimbo se suma a la comuna de Ovalle como part�cipe de este programa.<BR><BR>
Al mismo tiempo, con recursos del FNDR y el Banco Interamericano de Desarrollo, se formularon 14 planes de seguridad ciudadana para beneficiar a igual n�mero de comunas de la Regi�n.  Estos planes fueron elaborados con la participaci�n de los municipios y de la comunidad local, lo que ha permitido establecer l�neas de acci�n para una planificaci�n m�s eficaz.<BR><BR>
Para eso, tambi�n, se capacit� a 470 vecinos en estas materias, de manera de asegurar una intervenci�n local eficaz, que considere las particularidades de cada territorio.<BR><BR>
</p>

<p>
<B>CHILE SOLIDARIO</B><BR><BR>
Esto es parte de la pol�tica social del Gobierno, de lo que hacemos para asegurar el desarrollo de las personas.<BR><BR>
Durante el a�o pasado, asumimos tambi�n el desaf�o de terminar con la extrema pobreza.  El presidente Ricardo Lagos en su discurso del 21 de mayo del 2002, nos invit� a generar un cambio en la forma de hacer pol�tica social.  Nos invit� a construir un Chile m�s solidario.<BR><BR>
Hoy en nuestra regi�n, 2.200 familias de las quince comunas forman parte del sistema Chile Solidario, en el que superar la indigencia es una tarea conjunta entre el Gobierno y las familias.<BR><BR>
Asumimos un rol pro-activo en la lucha contra la pobreza, sin esperar que estas familias lleguen en b�squeda de un alg�n subsidio o programa social, sino visitando sus propios hogares para conocer directamente sus necesidades y otorgarles apoyo psicosocial.<BR><BR>
Estas familias, cuentan hoy con un acceso preferente en salud, educaci�n y en la mejora de sus condiciones de empleabilidad, a cambio de la firma de un contrato que los compromete a trabajar por su propio desarrollo.<BR><BR>
Esta es la forma en que hacemos pol�tica social.  Si hoy podemos hablar de superaci�n de la extrema pobreza, es gracias a ese compromiso, al esfuerzo de cada una de estas familias. <BR><BR>
</p>

<p>
<B>PROTECCI�N A LA FAMILIA</B><BR><BR>
Otra acci�n orientada a la protecci�n de la familia, es la que constituimos a mediados del a�o pasado, mediante la Red Protege.<BR><BR>
Esta red, est� dirigida a cautelar los derechos de la familia y a resguardarla de los efectos de la violencia intrafamiliar.<BR><BR>
El Gobierno Regional particip� de la instalaci�n del segundo centro de atenci�n para v�ctimas de violencia intrafamiliar ubicado en la provincia del Choapa.  Este establecimiento, complementa lo realizado por el centro ya operativo en Elqui, y es parte de una serie de acciones que considera, tambi�n, la realizaci�n de un estudio de prevalencia de la violencia intrafamiliar de la Regi�n de Coquimbo, que busca establecer los mecanismos de intervenci�n m�s efectivos en cada una de las quince comunas.<BR><BR>
</p>

<p>
<B>J�VENES</B><BR><BR>
Durante el a�o pasado, iniciamos una nueva forma de aproximaci�n a los j�venes, mediante la instalaci�n de los Centros de Informaci�n Juvenil en Coquimbo, Ovalle e Illapel, que se sumaron al ya existente en La Serena.<BR><BR>
Esta iniciativa regional, priorizada por el Consejo y que tuvo un valor superior a los 57 millones de pesos, ofrece acceso gratuito a las nuevas tecnolog�as de la informaci�n, adem�s de espacios para el encuentro y cursos de capacitaci�n, que van a los intereses directos de los j�venes.<BR><BR>
Estos centros reciben m�s de cien visitas diarias.<BR><BR>
Para este a�o, elaboraremos un plan regional que coordine de mejor manera la oferta p�blica en materias de inter�s para la juventud, como parte de la intersectorialidad que caracteriza nuestra gesti�n.<BR><BR>
</p>

<p>
<B>CONACE</B><BR><BR>
Un logro importante conseguido en el nivel regional, han sido los resultados del �ltimo estudio nacional realizado por CONACE, que muestra una disminuci�n considerable de la prevalencia de esta problem�tica en nuestra regi�n.<BR><BR>
Esto no significa que estemos conformes o que detengamos la intervenci�n al respecto.  Durante el 2002, se iniciaron programas destinados a prevenci�n desde las primeras etapas formativas de nuestros ni�os.  <BR><BR>
Al mismo tiempo, se avanz� en la rehabilitaci�n de las personas con drogodependencia, a trav�s de un convenio entre CONACE y FONASA.  De esta manera, se atendi� a 212 personas.<BR><BR>
La prevenci�n tambi�n se vivi� en las cuatro comunas m�s pobladas, gracias al programa Previene, que forma agentes preventivos y trabaja inserto en la comunidad.<BR><BR>
Para las 11 comunas que no cuentan con esta intervenci�n, el Gobierno Regional implement� el programa del Bus Conace, que con una inversi�n de 95 millones y medio de pesos, extender� la acci�n preventiva a todo el territorio.<BR><BR>

	</font>
	      </DIV>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr> 
          <td width="120" height="126" align="center"><img src="imagenes/boss.jpg" border="0" height="126"></td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="95"></td>
    <td valign="top"  class="tableborder"> 
<table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas01.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas011.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas02.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas021.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td colspan="2" valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="1220" height="25" valign="top"><img src="imagenes/mas03.gif" width="122" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas031.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas04.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas041.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>

    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
HTML;
?>
