<?
function cabeceraHTML(){
echo <<< HTML
<html>
<head>
<title>Cuenta P�blica Gesti�n 2003  - Gobierno Regional de Coquimbo </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/estilo.css" type="text/css">
<script language="JavaScript" src="js/cuenta.js"></script>
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="00" marginwidth="0" marginheight="0">
<center>
<table width="788" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="567" valign="top" height="125">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="125" height="125" valign="top"><img src="imagenes/top_up01.gif" width="125" height="125"></td>
          <td width="142" valign="top"><img src="imagenes/top_up02.gif" width="142" height="125"></td>
          <td width="150" valign="top"><img src="imagenes/top_up03.gif" width="150" height="125"></td>
          <td width="150" valign="top"><img src="imagenes/top_up04.gif" width="150" height="125"></td>
        </tr>
      </table>
    </td>
    <td width="95" valign="top">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="125" width="95" valign="top"><img src="imagenes/cta2003.gif" width="95" height="125"></td>
        </tr>
      </table>
    </td>
    <td width="126" valign="top"><img src="imagenes/top_up05.gif" width="126" height="125"></td>
  </tr>
</table>

<table width="790" border="0" cellpadding="0" cellspacing="0" class="tablebodytext">
  <tr>
    <td width="215" height="5"></td>
    <td width="280"></td>
    <td width="60"></td>
    <td width="235"></td>
  </tr>
  <tr >
    <td height="20" ColSpan="4" >
	<table width="790" border="0" cellpadding="0" cellspacing="0" class="tablebodytext" style="border: 1px solid rgb(188,211,250);">
	  <tr>
	    <td width="495" valign="middle" bgcolor="ffffff">&nbsp<a href="index.php"><img src="imagenes/home.gif" border="0"></a></td>
	    <td valign="top" bgcolor="#FFFFFF" align="right"><img src="imagenes/rytop01.gif" width="60" height="20"></td>
	    <td valign="middle" align="left" bgcolor="#FFFFFF">&nbsp;
	      <script language="JavaScript">
	      <!--
 	       fecha();
 	     // -->
	     </script>
	   </td>
	 </tr>
	</table>
    </td>
  </TR>
<tr>
    <td width="215" height="5"></td>
    <td width="280"></td>
    <td width="60"></td>
    <td width="235"></td>
  </tr>

</table>
HTML;
}

