<?
include("utils.php");
cabeceraHTML();

echo <<< HTML
<table width="790" border="0" cellpadding="1" cellspacing="1" bgcolor="#FFFFFF" class="tablebody" style="border: 1px solid rgb(188,211,250);">
  <tr> 
    <td width="170" valign="top" rowspan="5" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" >
        <tr> 
          <td width="150" height="278" valign="top" bgcolor="#FFFFFF">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
	      <tr><td></td></tr>
	      <tr>
		<td class="leftmenu" height="25">
			<a href="index.php">Introducci&oacute;n</a>
		</td>
	      </tr>
	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_02.php">Cuenta Gesti&oacute;n 2002</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_021.php">M&aacute;s Equidad</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_022.php">M&aacute;s Integraci&oacute;n</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_023.php">M&aacute;s Progreso</a>
                </td>
              </tr>
	      <tr>
                <td class="leftmenu" height="25">&nbsp;&nbsp;
                        <a href="cta_024.php">M&aacute;s Eficiencia</a>
                </td>
              </tr>
<tr>
                <td class="leftmenu" height="25">
                        <a href="cta_04.php">Tareas Pendientes</a>
                </td>
              </tr>

	      <tr>
                <td class="leftmenu" height="25">
                        <a href="cta_03.php">Cierre</a>
                </td>
              </tr>

	    </table>
	  </td>
        </tr>
      </table>
    </td>
    <td width="16" height="25"></td>
    <td width="120"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="6"></td>
    <td width="107"></td>
    <td width="13"></td>
    <td width="7"></td>
    <td width="120"></td>
    <td width="4"></td>
    <td width="120" valign="top" rowspan="5" > 
      <table width="100%" border="0" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="18" height="42"></td>
          <td width="78"></td>
          <td width="18"></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/gore.gif" border="0" width="80" height="80"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="2"></td>
          <td></td>
          <td></td>
        </tr>
        <tr> 
          <td height="80"></td>
          <td valign="top" bgcolor="#ffffff"><img src="imagenes/chile.gif" border="0" width="80" height="67"></td>
          <td></td>
        </tr>
        <tr> 
          <td height="56"></td>
          <td></td>
          <td></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="126"></td>
    <td colspan="5" valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="360" height="126">
              <DIV align="left" style="padding-left : 5px;    border: 1px solid #DDE5F2; HEIGHT: 126px; OVERFLOW: auto; WIDTH: 100%">
	<font class="tablebodytext">
<p>
M�S PROGRESO<BR><BR>
Con un territorio ordenado y una gran infraestructura hoy podemos enfrentar el desarrollo productivo de nuestra regi�n. S�lo con m�s progreso podemos asegurar m�s y mejores empleos, que permiten una mejor calidad de vida y una mayor equidad.<BR><BR>
</p>

<p>
<B>DESEMPLEO</B><BR><BR>
Sabemos que en cada hogar donde hay un desempleado, hay frustraci�n.  El flagelo del desempleo repercute en nuestras familias, nuestros ni�os. La impotencia de un jefe de hogar de no poder entregar a los suyos, muchas veces, ni siquiera los elementos m�s b�sicos para la subsistencia, es algo que queremos erradicar.<BR><BR>
El sue�o que nos inspira es el de una Regi�n con un fuerte progreso econ�mico, con habitantes capaces de emprender acciones que contribuyan a generarlo. Por eso es que durante el a�o pasado, la labor del Gobierno en la Regi�n estuvo focalizada en la generaci�n de redes de confianza entre empresarios, trabajadores y el Estado.<BR><BR>
Producto de esas redes, hoy podemos decir con orgullo que las cifras de desempleo bajaron considerablemente en el per�odo 2002 respecto de lo ocurrido el a�o anterior.<BR><BR>
En promedio, la econom�a regional gener� cada mes, 6 mil empleos m�s de lo que tuvimos mensualmente en el 2001, fundamentalmente en las �reas de la construcci�n y el comercio.<BR><BR>
Terminamos con los �ndices de dos d�gitos a la hora de hablar de desocupaci�n. Satisfechos podemos mostrar que la curva de desempleo durante todos los meses del a�o 2002 fue pr�cticamente dos puntos m�s baja que la del 2001.<BR><BR>
Con esto se comprueba, una vez m�s, que gracias a las condiciones econ�micas existentes tanto en nuestro pa�s como en nuestra regi�n, unidas a una buena coordinaci�n de los actores pol�ticos y a un escenario de paz social, se posibilita la generaci�n de confianzas y con ello el emprendimiento de todos los sectores.<BR><BR>
Nuestra tarea es que las inversiones que deseen venir, encuentren una v�a r�pida para su instalaci�n y concreci�n en la regi�n. No hay que olvidar que el 80 por ciento de los puestos de trabajo son generados por el sector privado, y que los programas gubernamentales de empleo, son y deben ser transitorios.<BR><BR>
</p>

<p>
<B>APORTE DEL GOBIERNO A LA GENERACI�N DE EMPLEO</B><BR><BR>
No obstante, el Gobierno mantendr� sus esfuerzos para apoyar a las familias que enfrentan la cesant�a y contribuir a la reinserci�n laboral de los desempleados.<BR><BR>
Por ello, es que hemos generado tanto pol�ticas de efecto permanente, entre las que se incluye el seguro de desempleo al que en nuestra regi�n ya se han integrado m�s de 17 mil trabajadores, como pol�ticas activas de efecto transitorio, en que destacan los programas de empleo con financiamiento fiscal.<BR><BR>
En estos programas, que beneficiaron a m�s de 46 mil jefes de familia ya fuera mediante empleos directos o subsidios a las empresas, el Gobierno invirti� 5 mil 500 millones de pesos.<BR><BR>
A eso se agregan los 52 mil 500 empleos generados en la empresa privada a trav�s de la inversi�n p�blica en la construcci�n de escuelas, caminos y viviendas.<BR><BR>
</p>

<p>
<B>COOPERACI�N P�BLICO/PRIVADA</B><BR><BR>
Queremos mejorar nuestros niveles de competencia y ganar nuevos mercados para las empresas y sus trabajadores.  En esta materia, la capacidad de colaboraci�n p�blico-privada es fundamental.<BR><BR>
La riqueza de los pa�ses hoy se asocia a las capacidades de sus trabajadores, a la innovaci�n y las buenas ideas que surgen del trabajo en equipo.<BR><BR>
La capacitaci�n es un tema clave para aumentar nuestra competitividad como regi�n. Por ello, de 29 mil trabajadores capacitados en el 2002, nos hemos puesto como meta para este a�o llegar a 35 mil.<BR><BR>
El a�o pasado destinamos 4 mil millones a capacitaci�n laboral, lo que representa casi tres veces lo invertido el a�o 2001.  Con estos recursos atrajimos a 3 mil nuevas empresas al uso de la franquicia tributaria para capacitaci�n, en lo que esperamos se convierta en una pr�ctica generalizada en el accionar del empresariado.<BR><BR>
Durante el 2002, tambi�n se capacit� a los peque�os mineros de la Regi�n en cursos de prevenci�n de riesgos, que los facultan para desempe�arse en tareas de la gran miner�a.  <BR><BR>
La entrega de esta capacitaci�n, se concentr� en 670 cesantes de toda la Regi�n, gracias al financiamiento de SENCE y de empresas mineras privadas.  Es un orgullo decir que m�s del 60 por ciento de los beneficiarios, hoy se encuentra trabajando.<BR><BR>
Para este a�o, pretendemos repetir la experiencia con al menos 500 nuevas personas.<BR><BR>
Adicionalmente, hemos invertido en becas de formaci�n en oficios, casi 100 millones de pesos el a�o 2002, orientados a trabajadores sin calificaci�n, mujeres y j�venes, cifra que esperamos triplicar durante este a�o.<BR><BR>
</p>

<p>
<B>CHILE CALIFICA</B><BR><BR>
Una nueva herramienta que hoy nos permite vincular la capacitaci�n a los requerimientos reales del �rea productiva de nuestra regi�n, es el programa de gobierno Chile Califica.<BR><BR>
El prop�sito de este programa es articular redes entre las instituciones educacionales y el sector econ�mico y productivo para el mejoramiento de la formaci�n t�cnico profesional. <BR><BR>
El a�o pasado, en conjunto con la Regi�n de Atacama, establecimos dos redes de acci�n en el �mbito acu�cola y agr�cola.<BR><BR>
Este fin de semana, recibimos la confirmaci�n que ambas redes, fueron seleccionadas por el Programa.  Esto significar� una atracci�n cercana a los 1.100 millones de pesos para ambas regiones.<BR><BR>
Todo este trabajo constituye una relevante apuesta como gobierno en la b�squeda de un desarrollo de largo alcance, que impacte en mejoras de calidad de vida permanentes para nuestros habitantes.<BR><BR>
</p>

<p>
<B>FOMENTO AL EMPRENDIMIENTO</B><BR><BR>
Las micro y peque�as empresas, concentran m�s del 80 por ciento de la fuerza laboral.  El apoyo a este sector en nuestra Regi�n, se expresa en una acci�n directa en que se aplican tanto los instrumentos de fomento de distintas instituciones, como otros programas generados considerando las particularidades de nuestro territorio.<BR><BR>
Fondos concursables administrados por el programa M�s Regi�n, se han sumado a los programas llevados por Sercotec, INDAP, SERNAM y FOSIS.  Durante el 2002, 1.785 millones de pesos se invirtieron directamente, con lo que se benefici� a 3.162 micro y peque�os empresarios.<BR><BR>
El total de los recursos puestos en la mediana, peque�a y micro empresa, fue de 17.800 millones de pesos.  Estos recursos p�blicos, apalancaron aportes del sector privado, incrementando de esta forma el esfuerzo por mejorar la competitividad de las empresas regionales.<BR><BR>
Coordinar la acci�n y focalizar el esfuerzo, es el sello de nuestra gesti�n, particularmente en materias de fomento productivo, con el fin de hacer m�s eficiente el uso de los recursos.<BR><BR>
Fondos de innovaci�n tecnol�gica<BR><BR>
As� generamos desde ya nuevas alternativas de desarrollo.  Por eso esperamos para este a�o 2003, colocar 400 millones de pesos, a trav�s del Fondo de Innovaci�n Tecnol�gica Regional.  Este es un esfuerzo que une recursos p�blicos atrayendo capital privado, y que ya ha generado una alta demanda a nivel empresarial.<BR><BR>
</p>

<p>
<B>IMPULSO A LA DIVERSIFICACI�N PRODUCTIVA</B><BR><BR>
Otro tema que nos preocupa como Gobierno, es el desarrollo y la integraci�n de todos los sectores productivos.<BR><BR>
En los pr�ximos d�as, concluir� una mesa de trabajo que se hizo cargo de una problem�tica de larga data en la comuna de Andacollo.  All� trabajamos en la b�squeda de soluciones y en la diversificaci�n productiva.<BR><BR>
Para asegurar la reactivaci�n econ�mica de la comuna, el Consejo Regional ya destin� 130 millones de pesos para la construcci�n del observatorio astron�mico tur�stico de Andacollo, que estar� funcionando para la pr�xima temporada estival.  Esta nueva iniciativa, comprende tambi�n la capacitaci�n de 30 andacollinos como gu�as tur�sticos en astronom�a.<BR><BR>
En la interacci�n p�blico-privada, ha quedado claramente en evidencia que la Regi�n tiene tres sectores econ�micos en los que cuenta con grandes ventajas competitivas y donde se concentra el mayor potencial de desarrollo a futuro:<BR><BR>
-	la agricultura,<BR><BR>
-	la acuicultura, y<BR><BR>
-	el turismo<BR><BR>
</p>

<p>
<B>AGRICULTURA</B><BR><BR>
Junto con la miner�a, la producci�n agr�cola presenta la mayor participaci�n en el Producto Interno Bruto Regional.<BR><BR>
Una de las acciones desarrolladas para diversificar y potenciar la producci�n agr�cola, fue el financiamiento v�a fondos regionales de programas de validaci�n tecnol�gica, que han permitido identificar distintas opciones productivas.<BR><BR>
El impacto de este programa, es evidente.  Con la identificaci�n de los frutales de nuez y las plantaciones oliv�colas como opciones productivas, hoy podemos hablar de la pr�xima instalaci�n de una planta de producci�n de aceite de oliva de la empresa espa�ola Borges, una de las m�s grandes del mundo.  Esta inversi�n, no s�lo generar� empleo, sino que traer� tecnolog�a de punta capaz de sustentar el desarrollo de una industria con mucho potencial a nivel nacional y latinoamericano.<BR><BR>
Esta producci�n unida a la instalaci�n de centros acu�colas y el desarrollo de plantaciones de eucaliptos, promovidos por CORFO, generar�n m�s de 1.000 nuevos empleos.<BR><BR>
En la lucha contra la desertificaci�n, CONAF aument� significativamente la superficie forestada, alcanzando un r�cord hist�rico de 4.856 hect�reas plantadas.<BR><BR>
Esto se realiz� con una importante participaci�n de las comunidades agr�colas, que est�n conscientes de la importancia del cuidado de sus recursos.<BR><BR>
En la provincia de Limar�, donde se concentra la mayor parte de la actividad agr�cola, el Gobierno Regional con el apoyo de los agricultores y de la Comisi�n Nacional de Riego, est� mejorando la eficiencia en el uso del agua, a trav�s de un sistema que emplea la informaci�n generada por estaciones meteorol�gicas, ubicadas a lo largo de 1.600 hect�reas.<BR><BR>
Adicionalmente, la Comisi�n Nacional de Riego benefici� a cerca de 3 mil agricultores de toda la Regi�n, mediante una bonificaci�n de tres mil 100 millones de pesos destinados al mejoramiento y construcci�n de infraestructura de riego.<BR><BR>
Pero, sin lugar a dudas, la mejor noticia para los peque�os agricultores es la continuidad de la acci�n desarrollada por el  programa PRODECOP, a trav�s de INDAP.  Esto es posible gracias al apoyo financiero del Gobierno Regional, la Asociaci�n de Municipios Rurales y el Ministerio de Agricultura.  As� estamos permitiendo que los microemprendimientos agr�colas, tengan un soporte de parte del Gobierno.<BR><BR>
</p>

<p>
<B>ACUICULTURA</B><BR><BR>
Gracias al financiamiento priorizado por el Consejo Regional, hemos generado un instrumento de planificaci�n del sector pesquero, que recogi� las iniciativas y acciones propuestas por los representantes de todos los actores.  Esto nos permitir� definir d�nde poner los �nfasis del desarrollo pesquero regional.<BR><BR>
Al mismo tiempo, se avanz� en el uso de las �reas de manejo, lo que redund� en mayores beneficios para los pescadores.  S�lo por dar un ejemplo, durante el 2002 se extrajo una mayor cantidad de locos, con el cuidado necesario para no agotar el recurso, gracias al control del 100 por ciento del producto extra�do.  Esto signific� mejorar la calidad de vida de 2 mil 900 pescadores y sus organizaciones.<BR><BR>
El Acuerdo de Producci�n Limpia para el Osti�n del Norte, alcanzado voluntariamente entre los productores y el Gobierno, ha definido est�ndares ambientales para los procesos productivos de esta industria.  Con ello, no s�lo aseguramos la calidad ambiental de las bah�as que sustentan esta actividad, sino su desarrollo como territorios tur�sticos.<BR><BR>
Dentro de esta actividad, la producci�n de ostiones fue de 10.267 toneladas, de las que el 8 por ciento corresponde al sector artesanal.<BR><BR>
Como podemos ver, una decisi�n t�cnico-administrativa permiti� que los sectores artesanales aumentaran su participaci�n en la producci�n regional.  Agradezco a los pescadores que han tomado las medidas de protecci�n de las �reas de manejo, asegurando la extracci�n de recursos en el largo plazo.<BR><BR>

	</font>
	      </DIV>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td valign="top" class="tableborder"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr> 
          <td width="120" height="126" align="center"><img src="imagenes/boss.jpg" border="0" height="126"></td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="95"></td>
    <td valign="top"  class="tableborder"> 
<table width="100%" border="0" cellpadding="0" cellspacing="0"  bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas01.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas011.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas02.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas021.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td colspan="2" valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="1220" height="25" valign="top"><img src="imagenes/mas03.gif" width="122" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas031.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td valign="top"  class="tableborder">
      <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="120" height="25" valign="top"><img src="imagenes/mas04.gif" width="120" height="25"></td>
        </tr>
        <tr>
          <td height="70"><img src="imagenes/mas041.gif" border="0"  height="70" width="120"></td>
        </tr>
      </table>

    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="5"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</center>
</body>
</html>
HTML;
?>
